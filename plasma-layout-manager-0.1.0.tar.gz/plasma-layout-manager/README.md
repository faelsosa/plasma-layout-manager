# Plasma Layout Manager

Save, restore, export and import KDE Plasma 6 layouts (panels, widgets,
appearance, window settings and shortcuts). Built with Python and PySide6, with
a native Qt/Breeze look. The interface is currently in Portuguese.

## Install

### Any distro (recommended)

    git clone https://github.com/YOUR_USER/plasma-layout-manager.git
    cd plasma-layout-manager
    ./install.sh

The script detects `pacman`, `apt`, `dnf` or `zypper`, installs the
dependencies, and adds the app to your application menu (per-user, no root
needed for the app itself). Use `./uninstall.sh` to remove it.

### Manual dependencies

| Distro | Command |
|---|---|
| Arch / Manjaro / EndeavourOS | `sudo pacman -S pyside6 plasma-integration qt6-tools` |
| Debian 13+ / Ubuntu 24.04+ / Kubuntu | `sudo apt install python3-pyside6.qtcore python3-pyside6.qtgui python3-pyside6.qtwidgets plasma-integration` |
| Fedora | `sudo dnf install python3-pyside6 plasma-integration qt6-qttools` |
| openSUSE | `sudo zypper install python3-pyside6 plasma6-integration` |

Use your distro's PySide6 package rather than `pip`, so the app matches the
system Qt and looks native on Plasma. Requires Python 3.11+.

Package names for apt, dnf and zypper are best-effort and may differ between
releases; please open an issue if one is wrong.

### Arch (PKGBUILD)

    makepkg -si

### Run without installing

    python -m plasma_layout_manager

## How it works

Layouts are stored in `~/.local/share/plasma-layout-manager/`. Applying a
layout creates a backup, stops `plasmashell` (otherwise it overwrites the files
on exit), copies the config files and restarts it.

## License

MIT
