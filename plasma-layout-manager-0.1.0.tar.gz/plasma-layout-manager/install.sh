#!/usr/bin/env bash
# Plasma Layout Manager - instalador por usuário (não precisa de root, exceto para
# instalar dependências do sistema). Uso: ./install.sh [--no-deps]
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
LIB="$HOME/.local/lib/plasma-layout-manager"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"

install_deps() {
  if command -v pacman >/dev/null; then
    sudo pacman -S --needed pyside6 plasma-integration qt6-tools
  elif command -v apt >/dev/null; then
    sudo apt update
    sudo apt install -y python3-pyside6.qtcore python3-pyside6.qtgui \
      python3-pyside6.qtwidgets plasma-integration
  elif command -v dnf >/dev/null; then
    sudo dnf install -y python3-pyside6 plasma-integration qt6-qttools
  elif command -v zypper >/dev/null; then
    sudo zypper install -y python3-pyside6 plasma6-integration
  else
    echo "Gerenciador de pacotes não reconhecido."
    echo "Instale manualmente: Python 3.11+, PySide6 e plasma-integration."
  fi
}

if [[ "${1:-}" != "--no-deps" ]]; then
  echo "==> Instalando dependências (pode pedir sua senha)…"
  install_deps || echo "Aviso: a instalação das dependências falhou; continuando."
fi

if ! python3 -c "import PySide6.QtWidgets" 2>/dev/null; then
  echo "ERRO: o Python não encontrou o PySide6. Instale-o e rode novamente."
  exit 1
fi

echo "==> Copiando arquivos…"
mkdir -p "$LIB" "$BIN" "$APPS"
rm -rf "$LIB/plasma_layout_manager"
cp -r "$SRC/plasma_layout_manager" "$LIB/"
find "$LIB" -name __pycache__ -prune -exec rm -rf {} +

cat > "$BIN/plasma-layout-manager" <<LAUNCHER
#!/usr/bin/env bash
export PYTHONPATH="$LIB\${PYTHONPATH:+:\$PYTHONPATH}"
exec python3 -m plasma_layout_manager "\$@"
LAUNCHER
chmod +x "$BIN/plasma-layout-manager"

sed "s|^Exec=.*|Exec=$BIN/plasma-layout-manager|" \
  "$SRC/plasma-layout-manager.desktop" > "$APPS/plasma-layout-manager.desktop"
command -v update-desktop-database >/dev/null && update-desktop-database "$APPS" || true
command -v kbuildsycoca6 >/dev/null && kbuildsycoca6 >/dev/null 2>&1 || true

echo "==> Pronto! Procure por 'Plasma Layout Manager' no menu de aplicativos."
case ":$PATH:" in *":$BIN:"*) ;; *) echo "Dica: adicione $BIN ao PATH para usar pelo terminal." ;; esac
