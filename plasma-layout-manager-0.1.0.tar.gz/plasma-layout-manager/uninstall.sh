#!/usr/bin/env bash
# Remove o programa. Seus layouts salvos em ~/.local/share/plasma-layout-manager são mantidos.
rm -rf "$HOME/.local/lib/plasma-layout-manager"
rm -f "$HOME/.local/bin/plasma-layout-manager" \
      "$HOME/.local/share/applications/plasma-layout-manager.desktop"
echo "Removido. Seus layouts continuam em ~/.local/share/plasma-layout-manager"
