"""Interface Qt (PySide6) do Plasma Layout Manager.

Sem estilo/paleta próprios: com o plasma-integration instalado, o Qt usa o
Breeze, as cores, fontes, ícones e diálogos de arquivo do Plasma do usuário.
"""
from __future__ import annotations

import html
import sys
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QIcon, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QGroupBox, QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QPlainTextEdit,
    QSplitter, QTextBrowser, QToolBar, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
)

from . import __version__
from .core import APP_ID, COMPONENTS, Layout, LayoutError, LayoutStore, slugify


def icon(name: str) -> QIcon:
    return QIcon.fromTheme(name)


def fmt_date(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return iso


class OptionsDialog(QDialog):
    """Diálogo genérico: nome/descrição opcionais + seleção de componentes."""

    def __init__(self, parent, title: str, ok_text: str, available: list[str],
                 checked: list[str], name: str | None = None,
                 description: str = "", intro: str = ""):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(440)
        lay = QVBoxLayout(self)
        if intro:
            lbl = QLabel(intro)
            lbl.setWordWrap(True)
            lay.addWidget(lbl)

        self.name_edit = self.desc_edit = None
        if name is not None:
            form = QFormLayout()
            self.name_edit = QLineEdit(name)
            self.desc_edit = QPlainTextEdit(description)
            self.desc_edit.setFixedHeight(70)
            form.addRow("Nome:", self.name_edit)
            form.addRow("Descrição:", self.desc_edit)
            lay.addLayout(form)

        self.boxes: dict[str, QCheckBox] = {}
        if available:
            group = QGroupBox("Componentes")
            gl = QVBoxLayout(group)
            for cid in available:
                comp = COMPONENTS[cid]
                cb = QCheckBox(comp.label)
                cb.setToolTip(comp.tip)
                cb.setChecked(cid in checked)
                cb.toggled.connect(self._validate)
                gl.addWidget(cb)
                self.boxes[cid] = cb
            lay.addWidget(group)

        self.buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                                        QDialogButtonBox.StandardButton.Cancel)
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText(ok_text)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        lay.addWidget(self.buttons)
        if self.name_edit:
            self.name_edit.textChanged.connect(self._validate)
        self._validate()

    def _validate(self) -> None:
        ok = True
        if self.name_edit and not self.name_edit.text().strip():
            ok = False
        if self.boxes and not self.selected():
            ok = False
        self.buttons.button(QDialogButtonBox.StandardButton.Ok).setEnabled(ok)

    def selected(self) -> list[str]:
        return [cid for cid, cb in self.boxes.items() if cb.isChecked()]


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.store = LayoutStore()
        self.setWindowTitle("Plasma Layout Manager")
        self.resize(1000, 600)
        self._build_actions()
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------ construção
    def _act(self, text, icon_name, slot, shortcut=None) -> QAction:
        a = QAction(icon(icon_name), text, self)
        a.triggered.connect(slot)
        if shortcut is not None:
            a.setShortcut(shortcut if isinstance(shortcut, QKeySequence)
                          else QKeySequence(shortcut))
        return a

    def _build_actions(self) -> None:
        K = QKeySequence.StandardKey
        self.a_save = self._act("&Salvar layout atual…", "document-save", self.save_current,
                                K.Save)
        self.a_apply = self._act("&Aplicar…", "dialog-ok-apply", self.apply_selected, "Ctrl+Return")
        self.a_edit = self._act("&Propriedades…", "document-properties", self.edit_selected, "F2")
        self.a_export = self._act("&Exportar…", "document-export", self.export_selected)
        self.a_import = self._act("&Importar…", "document-import", self.import_layout, K.Open)
        self.a_delete = self._act("E&xcluir", "edit-delete", self.delete_selected, K.Delete)
        self.a_refresh = self._act("A&tualizar", "view-refresh", self.refresh, K.Refresh)
        self.a_quit = self._act("&Sair", "application-exit", self.close, K.Quit)
        self.a_about = self._act("&Sobre", "help-about", self.about)
        self.selection_actions = [self.a_apply, self.a_edit, self.a_export, self.a_delete]

        m = self.menuBar()
        f = m.addMenu("&Arquivo")
        f.addActions([self.a_save, self.a_import, self.a_export])
        f.addSeparator()
        f.addAction(self.a_quit)
        l = m.addMenu("&Layout")
        l.addActions([self.a_apply, self.a_edit, self.a_delete, self.a_refresh])
        h = m.addMenu("A&juda")
        h.addAction(self.a_about)

        tb = QToolBar("Principal")
        tb.setMovable(False)
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        tb.addActions([self.a_save, self.a_apply])
        tb.addSeparator()
        tb.addActions([self.a_import, self.a_export, self.a_edit, self.a_delete])
        self.addToolBar(tb)

    def _build_ui(self) -> None:
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Nome", "Criado em", "Componentes"])
        self.tree.setColumnWidth(0, 230)
        self.tree.setColumnWidth(1, 130)
        self.tree.setAlternatingRowColors(True)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._context_menu)
        self.tree.currentItemChanged.connect(self._selection_changed)
        self.tree.itemDoubleClicked.connect(lambda *_: self.apply_selected())

        self.details = QTextBrowser()
        self.details.setOpenLinks(False)

        split = QSplitter()
        split.addWidget(self.tree)
        split.addWidget(self.details)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        self.setCentralWidget(split)
        self.statusBar()

    # ------------------------------------------------------------ dados
    def current(self) -> Layout | None:
        item = self.tree.currentItem()
        return item.data(0, Qt.ItemDataRole.UserRole) if item else None

    def refresh(self, select: Path | None = None) -> None:
        keep = select or (self.current().path if self.current() else None)
        self.tree.clear()
        groups = (("layouts", "Meus layouts", "folder"),
                  ("backups", "Backups automáticos", "document-open-recent"))
        target = None
        for kind, title, ic in groups:
            top = QTreeWidgetItem(self.tree, [title])
            top.setIcon(0, icon(ic))
            top.setFlags(top.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            for lay in self.store.list(kind):
                labels = ", ".join(COMPONENTS[c].label for c in lay.components)
                it = QTreeWidgetItem(top, [lay.name, fmt_date(lay.created), labels])
                it.setData(0, Qt.ItemDataRole.UserRole, lay)
                if keep and lay.path == keep:
                    target = it
            top.setExpanded(True)
        if target:
            self.tree.setCurrentItem(target)
        else:
            self._selection_changed()

    def _selection_changed(self, *_):
        lay = self.current()
        for a in self.selection_actions:
            a.setEnabled(lay is not None)
        self.a_edit.setEnabled(lay is not None and lay.kind == "layouts")
        self.details.setHtml(self._details_html(lay))

    def _details_html(self, lay: Layout | None) -> str:
        if not lay:
            return ("<h3>Plasma Layout Manager</h3><p>Selecione um layout ou clique em "
                    "<b>Salvar layout atual</b> para capturar o seu desktop.</p>")
        e = html.escape
        h = [f"<h2>{e(lay.name)}</h2>"]
        if lay.description:
            h.append(f"<p>{e(lay.description)}</p>")
        h.append(f"<p><b>Criado em:</b> {fmt_date(lay.created)}"
                 + (f"<br><b>Plasma:</b> {e(lay.plasma_version)}" if lay.plasma_version else "")
                 + "</p><p><b>Componentes:</b></p><ul>")
        h += [f"<li>{e(COMPONENTS[c].label)}</li>" for c in lay.components]
        h.append("</ul>")
        panels = lay.summary.get("panels", [])
        if panels or lay.summary.get("desktops"):
            h.append(f"<p><b>Painéis:</b> {len(panels)} &nbsp; "
                     f"<b>Áreas de trabalho:</b> {lay.summary.get('desktops', 0)}</p><ul>")
            for p in panels:
                w = ", ".join(e(x) for x in p["widgets"] if x) or "—"
                h.append(f"<li>Painel ({e(p['location'])}): {w}</li>")
            h.append("</ul>")
        return "".join(h)

    # ------------------------------------------------------------ ações
    def _error(self, err: Exception) -> None:
        QMessageBox.critical(self, "Erro", str(err))

    def save_current(self) -> None:
        default = [c.id for c in COMPONENTS.values() if c.default]
        dlg = OptionsDialog(self, "Salvar layout atual", "Salvar", list(COMPONENTS), default,
                            name=f"Layout {datetime.now():%d-%m-%Y %H:%M}")
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            lay = self.store.save_current(dlg.name_edit.text(), dlg.desc_edit.toPlainText(),
                                          dlg.selected())
        except LayoutError as e:
            return self._error(e)
        self.refresh(lay.path)
        self.statusBar().showMessage(f"Layout «{lay.name}» salvo.", 6000)

    def apply_selected(self) -> None:
        lay = self.current()
        if not lay:
            return
        intro = ("Um backup da configuração atual será criado e o <b>plasmashell</b> será "
                 "reiniciado por alguns segundos.")
        dlg = OptionsDialog(self, f"Aplicar «{lay.name}»", "Aplicar", lay.components,
                            lay.components, intro=intro)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        log: list[str] = []
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self.store.apply(lay, dlg.selected(), log.append)
        except LayoutError as e:
            QApplication.restoreOverrideCursor()
            return self._error(e)
        finally:
            while QApplication.overrideCursor():
                QApplication.restoreOverrideCursor()
        self.refresh()
        self.statusBar().showMessage(f"Layout «{lay.name}» aplicado.", 8000)
        self.details.append("<hr><pre>" + html.escape("\n".join(log)) + "</pre>")

    def edit_selected(self) -> None:
        lay = self.current()
        if not lay or lay.kind != "layouts":
            return
        dlg = OptionsDialog(self, "Propriedades do layout", "OK", [], [],
                            name=lay.name, description=lay.description)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            try:
                self.store.update(lay, dlg.name_edit.text(), dlg.desc_edit.toPlainText())
            except LayoutError as e:
                return self._error(e)
            self.refresh(lay.path)

    def delete_selected(self) -> None:
        lay = self.current()
        if not lay:
            return
        r = QMessageBox.question(self, "Excluir layout",
                                 f"Excluir «{lay.name}» permanentemente?",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                 QMessageBox.StandardButton.No)
        if r == QMessageBox.StandardButton.Yes:
            self.store.delete(lay)
            self.refresh()

    def export_selected(self) -> None:
        lay = self.current()
        if not lay:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Exportar layout", f"{slugify(lay.name)}.plasmalayout.tar.gz",
            "Layouts do Plasma (*.tar.gz)")
        if path:
            try:
                self.store.export(lay, Path(path))
            except OSError as e:
                return self._error(e)
            self.statusBar().showMessage(f"Exportado para {path}", 6000)

    def import_layout(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Importar layout", "",
                                              "Layouts do Plasma (*.tar.gz *.tgz)")
        if path:
            try:
                lay = self.store.import_archive(Path(path))
            except LayoutError as e:
                return self._error(e)
            self.refresh(lay.path)
            self.statusBar().showMessage(f"Layout «{lay.name}» importado.", 6000)

    def _context_menu(self, pos) -> None:
        if not self.current():
            return
        m = QMenu(self)
        m.addActions([self.a_apply, self.a_edit, self.a_export])
        m.addSeparator()
        m.addAction(self.a_delete)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def about(self) -> None:
        QMessageBox.about(self, "Sobre o Plasma Layout Manager",
                          f"<h3>Plasma Layout Manager {__version__}</h3>"
                          "<p>Salve, restaure e compartilhe layouts do KDE Plasma.</p>"
                          "<p>Python + PySide6 (Qt 6).</p>")


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_ID)
    app.setApplicationDisplayName("Plasma Layout Manager")
    app.setApplicationVersion(__version__)
    app.setDesktopFileName(APP_ID)  # necessário no Wayland para ícone/agrupamento
    app.setWindowIcon(QIcon.fromTheme("preferences-desktop-plasma"))
    win = MainWindow()
    win.show()
    return app.exec()
