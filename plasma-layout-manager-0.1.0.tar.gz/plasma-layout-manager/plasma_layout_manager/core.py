"""Lógica do Plasma Layout Manager (sem dependência de Qt, testável em headless)."""
from __future__ import annotations

import configparser
import json
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

APP_ID = "plasma-layout-manager"
META = "meta.json"
PLASMASHELL_UNIT = "plasma-plasmashell.service"

Log = Callable[[str], None]


class LayoutError(Exception):
    """Erro apresentável ao usuário."""


@dataclass(frozen=True)
class Component:
    id: str
    label: str
    tip: str
    files: tuple[str, ...]
    default: bool = True


COMPONENTS: dict[str, Component] = {
    c.id: c
    for c in (
        Component("panels", "Painéis e widgets",
                  "Painéis, widgets e containments da área de trabalho",
                  ("plasma-org.kde.plasma.desktop-appletsrc", "plasmashellrc")),
        Component("appearance", "Aparência",
                  "Esquema de cores, fontes, tema do Plasma e ícones",
                  ("kdeglobals", "plasmarc", "breezerc")),
        Component("windows", "Janelas e efeitos",
                  "KWin: decorações, efeitos, ladrilhamento e regras de janela",
                  ("kwinrc", "kwinrulesrc"), default=False),
        Component("input", "Cursor e dispositivos de entrada",
                  "Tema de cursor, mouse e touchpad",
                  ("kcminputrc",), default=False),
        Component("shortcuts", "Atalhos globais",
                  "Atalhos de teclado do Plasma/KWin (alguns exigem novo login)",
                  ("kglobalshortcutsrc", "khotkeysrc"), default=False),
    )
}
ALLOWED_FILES = {f for c in COMPONENTS.values() for f in c.files}


# ---------------------------------------------------------------- caminhos
def config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def data_home() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / APP_ID


def slugify(text: str) -> str:
    s = re.sub(r"[^\w\-]+", "-", text.strip(), flags=re.UNICODE).strip("-_").lower()
    return s[:60] or "layout"


# ---------------------------------------------------------------- resumo
_LOCATIONS = {3: "topo", 4: "inferior", 5: "esquerda", 6: "direita"}


def summarize_appletsrc(path: Path) -> dict:
    """Lê (somente leitura) o appletsrc e resume painéis, widgets e desktops."""
    result = {"panels": [], "desktops": 0}
    cp = configparser.ConfigParser(interpolation=None, strict=False, allow_no_value=True)
    cp.optionxform = str  # chaves do KDE diferenciam maiúsculas
    try:
        cp.read(path, encoding="utf-8")
    except (configparser.Error, OSError, UnicodeDecodeError):
        return result

    containments: dict[str, configparser.SectionProxy] = {}
    applets: dict[str, list[str]] = {}
    for sec in cp.sections():
        if m := re.fullmatch(r"Containments\]\[(\d+)", sec):
            containments[m.group(1)] = cp[sec]
        elif m := re.fullmatch(r"Containments\]\[(\d+)\]\[Applets\]\[\d+", sec):
            plugin = cp[sec].get("plugin") or ""
            applets.setdefault(m.group(1), []).append(plugin.removeprefix("org.kde.plasma."))

    for cid, sec in containments.items():
        plugin = sec.get("plugin") or ""
        if plugin == "org.kde.panel":
            try:
                loc = _LOCATIONS.get(int(sec.get("location") or -1), "?")
            except ValueError:
                loc = "?"
            result["panels"].append({"location": loc, "widgets": applets.get(cid, [])})
        elif plugin and "systemtray" not in plugin:
            result["desktops"] += 1
    return result


def plasma_version() -> str:
    try:
        out = subprocess.run(["plasmashell", "--version"], capture_output=True,
                             text=True, timeout=5).stdout.strip()
        return out.split()[-1] if out else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


# ---------------------------------------------------------------- modelo
@dataclass
class Layout:
    path: Path
    kind: str
    name: str
    description: str = ""
    created: str = ""
    components: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    plasma_version: str = ""
    summary: dict = field(default_factory=dict)

    @property
    def id(self) -> str:
        return self.path.name

    @classmethod
    def from_dir(cls, path: Path, kind: str) -> "Layout":
        try:
            meta = json.loads((path / META).read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise LayoutError(f"Metadados inválidos em {path.name}: {e}") from e
        files = [f for f in meta.get("files", []) if f in ALLOWED_FILES]
        comps = [c for c in meta.get("components", []) if c in COMPONENTS]
        return cls(path, kind, str(meta.get("name") or path.name),
                   str(meta.get("description", "")), str(meta.get("created", "")),
                   comps, files, str(meta.get("plasma_version", "")),
                   meta.get("summary", {}))

    def write_meta(self) -> None:
        data = {
            "format": 1, "name": self.name, "description": self.description,
            "created": self.created, "components": self.components,
            "files": self.files, "plasma_version": self.plasma_version,
            "summary": self.summary,
        }
        (self.path / META).write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                      encoding="utf-8")


# ---------------------------------------------------------------- sistema
def _run(cmd: list[str], timeout: float = 15) -> bool:
    try:
        return subprocess.run(cmd, capture_output=True, timeout=timeout).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def _plasmashell_stop(log: Log) -> str:
    """Para o plasmashell para que ele não sobrescreva os arquivos ao sair."""
    if _run(["systemctl", "--user", "is-active", "--quiet", PLASMASHELL_UNIT], 5):
        log("Parando plasmashell (systemd)…")
        _run(["systemctl", "--user", "stop", PLASMASHELL_UNIT], 30)
        return "systemd"
    log("Parando plasmashell…")
    if shutil.which("kquitapp6"):
        _run(["kquitapp6", "plasmashell"], 10)
    for _ in range(40):
        if not _run(["pgrep", "-x", "plasmashell"], 3):
            break
        time.sleep(0.25)
    return "direct"


def _plasmashell_start(mode: str, log: Log) -> None:
    log("Iniciando plasmashell…")
    if mode == "systemd" and _run(["systemctl", "--user", "start", PLASMASHELL_UNIT], 30):
        return
    for cmd in (["kstart", "plasmashell"], ["plasmashell"]):
        if shutil.which(cmd[0]):
            subprocess.Popen(cmd, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    log("Não foi possível reiniciar o plasmashell; execute 'plasmashell --replace'.")


def _kwin_reconfigure(log: Log) -> None:
    for tool in ("qdbus6", "qdbus-qt6", "qdbus"):
        if shutil.which(tool):
            if _run([tool, "org.kde.KWin", "/KWin", "reconfigure"], 5):
                log("KWin reconfigurado.")
            return


def _install(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".plm-tmp")
    shutil.copy2(src, tmp)
    os.replace(tmp, dest)


# ---------------------------------------------------------------- repositório
class LayoutStore:
    def __init__(self, root: Path | None = None, config_dir: Path | None = None):
        self.root = root or data_home()
        self.config_dir = config_dir or config_home()
        self.dirs = {"layouts": self.root / "layouts", "backups": self.root / "backups"}
        for d in self.dirs.values():
            d.mkdir(parents=True, exist_ok=True)

    def list(self, kind: str = "layouts") -> list[Layout]:
        out = []
        for p in self.dirs[kind].iterdir():
            if (p / META).is_file():
                try:
                    out.append(Layout.from_dir(p, kind))
                except LayoutError:
                    continue
        return sorted(out, key=lambda l: l.created, reverse=True)

    def _unique_dir(self, kind: str, base: str) -> Path:
        d = self.dirs[kind] / base
        n = 2
        while d.exists():
            d = self.dirs[kind] / f"{base}-{n}"
            n += 1
        return d

    def save_current(self, name: str, description: str = "",
                     components: list[str] | None = None,
                     kind: str = "layouts") -> Layout:
        name = name.strip()
        if not name:
            raise LayoutError("Informe um nome para o layout.")
        comps = [c for c in (components if components is not None else
                             [c.id for c in COMPONENTS.values() if c.default]) if c in COMPONENTS]
        files = [f for c in comps for f in COMPONENTS[c].files
                 if (self.config_dir / f).is_file()]
        if not files:
            raise LayoutError("Nenhum arquivo de configuração encontrado para os "
                              "componentes selecionados.")
        now = datetime.now()
        base = f"backup-{now:%Y%m%d-%H%M%S}" if kind == "backups" else slugify(name)
        d = self._unique_dir(kind, base)
        (d / "files").mkdir(parents=True)
        for f in files:
            shutil.copy2(self.config_dir / f, d / "files" / f)
        summary = {}
        if "plasma-org.kde.plasma.desktop-appletsrc" in files:
            summary = summarize_appletsrc(d / "files" / "plasma-org.kde.plasma.desktop-appletsrc")
        layout = Layout(d, kind, name, description.strip(), now.isoformat(timespec="seconds"),
                        comps, files, plasma_version(), summary)
        layout.write_meta()
        return layout

    def apply(self, layout: Layout, components: list[str] | None = None,
              log: Log = lambda m: None) -> None:
        wanted = [c for c in (components or layout.components)
                  if c in layout.components and c in COMPONENTS]
        files = [f for c in wanted for f in COMPONENTS[c].files
                 if f in layout.files and (layout.path / "files" / f).is_file()]
        if not files:
            raise LayoutError("O layout não contém arquivos para os componentes escolhidos.")

        try:
            bk = self.save_current(f"Backup antes de aplicar «{layout.name}»",
                                   components=wanted, kind="backups")
            log(f"Backup criado: {bk.id}")
        except LayoutError:
            log("Sem configuração atual para backup.")

        mode = _plasmashell_stop(log)
        try:
            for f in files:
                _install(layout.path / "files" / f, self.config_dir / f)
                log(f"Restaurado: {f}")
        finally:
            _plasmashell_start(mode, log)
        if set(wanted) & {"windows", "appearance"}:
            _kwin_reconfigure(log)

    def update(self, layout: Layout, name: str, description: str) -> None:
        if not name.strip():
            raise LayoutError("Informe um nome para o layout.")
        layout.name, layout.description = name.strip(), description.strip()
        layout.write_meta()

    def delete(self, layout: Layout) -> None:
        shutil.rmtree(layout.path)

    def export(self, layout: Layout, dest: Path) -> None:
        with tarfile.open(dest, "w:gz") as tar:
            tar.add(layout.path, arcname=layout.path.name)

    def import_archive(self, src: Path) -> Layout:
        with tempfile.TemporaryDirectory() as tmp:
            try:
                with tarfile.open(src, "r:*") as tar:
                    tar.extractall(tmp, filter="data")
            except (tarfile.TarError, OSError) as e:
                raise LayoutError(f"Arquivo inválido: {e}") from e
            tmp_path = Path(tmp)
            candidates = [p.parent for p in tmp_path.rglob(META)
                          if len(p.relative_to(tmp_path).parts) <= 2]
            if len(candidates) != 1:
                raise LayoutError("O arquivo não contém um layout válido.")
            layout = Layout.from_dir(candidates[0], "layouts")
            if not layout.files:
                raise LayoutError("O layout importado não possui arquivos reconhecidos.")
            dest = self._unique_dir("layouts", slugify(layout.name))
            shutil.copytree(candidates[0], dest)
        return Layout.from_dir(dest, "layouts")
