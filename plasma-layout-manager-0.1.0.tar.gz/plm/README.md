# Plasma Layout Manager

Salva, restaura, exporta e importa layouts do KDE Plasma 6 (painéis, widgets,
aparência, janelas e atalhos). Python + PySide6.

## Dependências (Arch Linux)

    sudo pacman -S pyside6 plasma-integration qt6-tools

Use o `pyside6` do pacman (não o do pip): ele é compilado contra o Qt do
sistema, o que garante o visual nativo do Plasma (Breeze, cores, ícones e
diálogos de arquivo do KDE).

## Executar

    python -m plasma_layout_manager

## Instalar no menu de aplicativos

    pipx install --system-site-packages .
    install -Dm644 plasma-layout-manager.desktop ~/.local/share/applications/plasma-layout-manager.desktop

## Onde ficam os dados

`~/.local/share/plasma-layout-manager/{layouts,backups}`

Ao aplicar um layout, o app cria um backup, para o plasmashell (senão ele
sobrescreve os arquivos ao sair), copia os arquivos e reinicia o plasmashell.
